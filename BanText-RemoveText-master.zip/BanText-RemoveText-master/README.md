![before](README/en_before.jpg)

![after](README/en_after.jpg)

![settings1](README/en_settings1.JPG)


[Latest Release](https://github.com/ohsorry/BlockText/releases)
